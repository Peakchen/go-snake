
$repo = "git@github.com:mongodb/specifications"

git clone $repo

go generate ../