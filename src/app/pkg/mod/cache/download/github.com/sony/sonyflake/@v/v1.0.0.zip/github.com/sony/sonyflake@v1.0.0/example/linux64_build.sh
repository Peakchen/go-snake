#!/bin/sh
GOOS=linux GOARCH=amd64 go build sonyflake_server.go
