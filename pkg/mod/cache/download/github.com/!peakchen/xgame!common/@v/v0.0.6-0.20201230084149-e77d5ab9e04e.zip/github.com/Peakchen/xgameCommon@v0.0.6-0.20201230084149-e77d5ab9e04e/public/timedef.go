package public

const (
	CstTimeFmt  string = "2006-01-02 15:04:05.000000 Z0700"
	CstTimeDate string = "2006-01-02"
)
