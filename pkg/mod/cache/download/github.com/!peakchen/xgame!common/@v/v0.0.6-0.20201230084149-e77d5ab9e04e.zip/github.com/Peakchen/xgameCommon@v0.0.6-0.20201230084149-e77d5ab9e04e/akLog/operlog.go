package akLog

/*
	game operation log.
*/
