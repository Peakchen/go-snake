package Config

/*
	config use template for others example..
*/
type TemplateConfig struct {
}

func (this *TemplateConfig) ComfireAct(data interface{}) (errlist []string) {

	return
}

func (this *TemplateConfig) DataRWAct(data interface{}) (errlist []string) {

	return
}
