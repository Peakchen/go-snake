package akRpc

// rpc father class.

type AoRpcIF interface {
	AfterCall() error
}
