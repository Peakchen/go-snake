## make fast net for game by kcp.
### by stefan.