package Cache

const (
	ConstBigWordHost string = "127.0.0.1:31000"
)

const (
	ConstCacheOverTime   int64 = 60 * 10 //10 min
	ConstCacheUpdateTime int64 = 60 * 30 //30 min
)
