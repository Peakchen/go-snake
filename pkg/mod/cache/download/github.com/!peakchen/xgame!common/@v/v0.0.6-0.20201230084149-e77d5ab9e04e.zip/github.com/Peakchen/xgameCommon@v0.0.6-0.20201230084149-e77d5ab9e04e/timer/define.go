package timer

const (
	// timer
	cstTimerUpLimit = 1000
)
