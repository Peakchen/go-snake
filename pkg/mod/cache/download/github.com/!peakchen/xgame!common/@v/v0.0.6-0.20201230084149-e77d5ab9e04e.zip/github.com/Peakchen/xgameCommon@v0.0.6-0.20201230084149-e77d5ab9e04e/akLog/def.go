package akLog

const (
	KAFKA_LOG_TOPIC          = "log"
	KAFKA_LOG_CONSUMER_GROUP = "test-consumer-group"
)
