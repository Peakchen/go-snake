package timer

/*
	design for distributed timer by redis.
*/
